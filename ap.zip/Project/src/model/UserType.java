package model;

public enum UserType {
    TeamMember,
    TeamLeader,
    SystemAdministrator
}
