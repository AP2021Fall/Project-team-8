package model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Task {

    private static int lastId = 0;
    private static final ArrayList<Task> allTasks;
    private static ArrayList<User> assignedUsers;
    private final int id;
    private String title;
    private String description;
    private String priority;
    private LocalDateTime dateAndTimeOfCreation;
    private String dateAndTimeOfDeadline;
    private User owner;

    static {
        allTasks = new ArrayList<>();
    }

    public Task(String title, String description, String priority, LocalDateTime dateAndTimeOfCreation, String dateAndTimeOfDeadline, User user) {
        this.description = description;
        this.priority = priority;
        this.dateAndTimeOfCreation = dateAndTimeOfCreation;
        this.dateAndTimeOfDeadline = dateAndTimeOfDeadline;
        id = lastId;
        lastId ++;
        this.title = title;
        this.owner = user;
        allTasks.add(this);
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public User getOwner() {
        return owner;
    }

    public String getDescription() {
        return description;
    }

    public LocalDateTime getDateAndTimeOfCreation() {
        return dateAndTimeOfCreation;
    }

    public String getDateAndTimeOfDeadline() {
        return dateAndTimeOfDeadline;
    }

    public void getAssignedUsers() {
        for (User user:
                assignedUsers) {
            System.out.println(user.getUsername());
        }
    }

    public String getPriority() {
        return priority;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDateAndTimeOfDeadline(String dateAndTimeOfDeadline) {
        this.dateAndTimeOfDeadline = dateAndTimeOfDeadline;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public static ArrayList<Task> getAllTasks() {
        return allTasks;
    }

    public void setOwner(User owner) {
        this.owner = owner;
    }

    public static void setAssignedUsers(User user) {
        Task.assignedUsers.add(user);
    }

    public static void deleteAssignedUsers(User user) {
        Task.assignedUsers.remove(user);
    }

    public void setTitle(String title) {this.title = title;}

    public void setDateAndTimeOfCreation(LocalDateTime dateAndTimeOfCreation) {
        this.dateAndTimeOfCreation = dateAndTimeOfCreation;
    }

    public static Task findTaskById(int id) {
        for (Task task : allTasks) {
            if(task.getId() == id) {
                return task;
            }
        }
        return null;
    }

    public static Task findTaskByTitle(String title) {
        for (Task task : allTasks) {
            if(task.getTitle().equalsIgnoreCase(title)) {
                return task;
            }
        }
        return null;
    }
//something is wrong here!
    public static ArrayList<Task> getUserTasks(User user) {
        ArrayList<Task> userTasks = new ArrayList<>();
        for (Task task : allTasks) {
            if(task.getOwner().getUsername().equalsIgnoreCase(user.getUsername())) {
                userTasks.add(task);
            }
        }
        return userTasks;
    }

    public static void changeTaskTitle(int id, String title) {
        Task.findTaskById(id).setTitle(title);
    }

    public static void changeTaskDescription(int id, String description) {
        Task.findTaskById(id).setDescription(description);
    }

    public static void changeTaskPriority(int id, String priority) {
        Task.findTaskById(id).setPriority(priority);
    }

    public static void changeTaskDeadline(int id, String deadline) {
        Task.findTaskById(id).setDateAndTimeOfDeadline(deadline);
    }
}