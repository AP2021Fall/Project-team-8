package model;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class User {
    private static final ArrayList<User> allUsers;

    static {
        allUsers = new ArrayList<>();
    }

    private String username;
    private String password;
    private UserType userType;
    private String email;
    private boolean userLogIn;
    private static ArrayList<String> allEmails = new ArrayList<>();


    public User(String username, String password, UserType userType, String email, boolean userLogIn) {
        this.username = username;
        this.password = password;
        this.userType = userType;
        this.email = email;
        this.userLogIn = userLogIn;

        allUsers.add(this);
        allEmails.add(email);
    }

    public static boolean isEmailUnique(String email) {
        return !allEmails.contains(email);
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUserType(UserType userType) { this.userType = userType;}

    public void setEmail(String email) { this.email = email;}

    public void setUserLogIn(boolean userLogIn) {
        this.userLogIn = userLogIn;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public UserType getUserType() {return userType;}

    public String getEmail() { return email;}

    public boolean getUserLogIn() {return userLogIn;}

    public static boolean isUsernameUnique(String username) {
        for (User user : allUsers) {
            if (user.getUsername().equalsIgnoreCase(username)) {
                return false;
            }
        }
        return true;
    }

    public static boolean doubleCheckPassword(String password, String password_prime) {
        return password.equals(password_prime);
    }


    public static boolean doesUsernameExists(String username) {
        for (User user : allUsers) {
            if (user.getUsername().equalsIgnoreCase(username)) {
                return true;
            }
        }
        return false;
    }

    public static boolean checkPassword(String username, String password) {
        for (User user : allUsers) {
            if (user.getUsername().equalsIgnoreCase(username)) {
                if (user.getPassword().equals(password)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean checkPasswordPattern(String password) {
        Pattern passwordPattern = Pattern.compile("[0-9]{1}[A-Z]{1}");
        Matcher checkPassword = passwordPattern.matcher(password);
        if (password.length() < 8)
            return false;
        else
            return checkPassword.find();
    }

    public static boolean checkUsernamePattern(String username) {
        Pattern usernamePattern = Pattern.compile("^[\\w]$");
        Matcher checkUsername = usernamePattern.matcher(username);
        return checkUsername.find();
    }

    public static User getUser(String username, String password) {
        for (User user : allUsers) {
            if (user.getUsername().equalsIgnoreCase(username)) {
                if (user.getPassword().equals(password)) {
                    return user;
                }
            }
        }
        return null;
    }

    public static User getUserByUsername(String username) {
        for (User user : allUsers) {
            if (user.getUsername().equalsIgnoreCase(username)) {
                return user;
            }
        }
        return null;
    }

    public static boolean isEmailCorrect(String email) {
        Pattern emailPattern1 = Pattern.compile("@gmail.com$");
        Pattern emailPattern2 = Pattern.compile("@yahoo.com$");
        Pattern emailPattern4 = Pattern.compile("^\\w+");
        Matcher pattern1Matcher = emailPattern1.matcher(email);
        Matcher pattern2Matcher = emailPattern2.matcher(email);
        Matcher pattern4Matcher = emailPattern4.matcher(email);
        System.out.println(email);
        return pattern4Matcher.find() && (pattern1Matcher.find() || pattern2Matcher.find());
    }
}