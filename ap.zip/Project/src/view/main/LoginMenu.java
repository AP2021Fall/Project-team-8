package view.main;

import model.User;
import view.MainMenu;
import view.WelcomeMenu;

import java.util.Scanner;

public class LoginMenu {

    // make class singleton
    private LoginMenu(Scanner scanner) {
        this.scanner = scanner;
    }

    private static LoginMenu instance;
    private Scanner scanner;

    public static LoginMenu getInstance(Scanner scanner) {
        if (instance == null) {
            instance = new LoginMenu(scanner);
        }
        instance.scanner = scanner;
        return instance;
    }

    public void main() {
        System.out.println("Login Menu:");
        System.out.println("0- Back");
        String input = scanner.nextLine();
        if (input.equals("0")) {
            WelcomeMenu.getInstance(scanner).showWelcomeMessage();
        } else if () {

        } else
            LoginMenu.getInstance(scanner).main();
    }

    public void loginUser(String userName, String password) {
        if (User.doesUsernameExists(userName)) {
            if (User.checkPassword(userName, password)) {
                System.out.println("user logged in successfully");
                User.getUser(userName, password).setUserLogIn(true);
                MainMenu.getInstance(scanner, User.getUser(userName, password), null).showMainMessage();
            } else {
                System.out.println("Username and password didn’t match!");
                LoginMenu.getInstance(scanner).main();
            }
        } else {
            System.out.println("There is not any user with username: " + userName + "!");
            LoginMenu.getInstance(scanner).main();
        }
    }
}
