package view.main;

import model.User;
import model.UserType;
import view.WelcomeMenu;

import java.util.Scanner;

public class RegisterMenu {

    // make class singleton
    private RegisterMenu(Scanner scanner) {
        this.scanner = scanner;
    }

    private static RegisterMenu instance;
    private Scanner scanner;

    public static RegisterMenu getInstance(Scanner scanner) {
        if (instance == null) {
            instance = new RegisterMenu(scanner);
        }
        instance.scanner = scanner;
        return instance;
    }

    public void main() {
        System.out.println("Register Menu: ");
        System.out.println("0- Back");
        String input = scanner.nextLine();
        if (input.equals("0")) {
            WelcomeMenu.getInstance(scanner).showWelcomeMessage();
        } else if () {

        } else
            RegisterMenu.getInstance(scanner).main();
    }

    public void createUser(String userName, UserType userType, String password1, String password2, String email) {
        if (User.isUsernameUnique(userName)) {
            if (User.doubleCheckPassword(password1, password2)) {
                if (User.isEmailUnique(email)) {
                    if (User.isEmailCorrect(email)) {
                        new User(userName, password1, userType, email, false);
                        System.out.println("Register is done successfully!");
                        LoginMenu.getInstance(scanner).main();
                    } else {
                        System.out.println("Email address is invalid!");
                        RegisterMenu.getInstance(scanner).main();
                    }
                } else {
                    System.out.println("User with this email already exists!\n");
                    RegisterMenu.getInstance(scanner).main();
                }
            } else {
                System.out.println("Your passwords are not the same!");
                RegisterMenu.getInstance(scanner).main();
            }
        } else {
            System.out.println("user with username " + userName + " already exists!\n");
            RegisterMenu.getInstance(scanner).main();
        }
    }
}