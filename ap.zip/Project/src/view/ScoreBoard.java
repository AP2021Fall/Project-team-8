package view;

public class ScoreBoard {
}
