package view;

import model.Task;
import model.User;

import java.util.Scanner;

public class NotificationBar {

    // make class singleton
    private NotificationBar(Scanner scanner, User user, Task task) {
        this.scanner = scanner;
        this.user = user;
        this.task = task;
    }

    private static NotificationBar instance;
    private Scanner scanner;
    private User user;
    private Task task;

    public static NotificationBar getInstance(Scanner scanner, User user, Task task) {
        if (instance == null) {
            instance = new NotificationBar(scanner, user, task);
        }
        instance.scanner = scanner;
        instance.user = user;
        instance.task = task;
        return instance;
    }

    public void main() {
        System.out.println("Notification Bar:");
        System.out.println("0- Back");
        String input = scanner.nextLine();
        if (input.equals("0")) {
            MainMenu.getInstance(scanner, user, task).showMainMessage();
        } else if () {

        } else
            NotificationBar.getInstance(scanner, user, task).main();
    }
}
