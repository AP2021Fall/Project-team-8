package view;

public class Boardmenu {
}
