package view;

public class ChatRoom {
}
