package view;

import model.Task;
import model.User;

import java.util.Scanner;

public class TeamMenu {

    // make class singleton
    private TeamMenu(Scanner scanner, User user, Task task) {
        this.scanner = scanner;
        this.user = user;
        this.task = task;
    }

    private static TeamMenu instance;
    private Scanner scanner;
    private User user;
    private Task task;

    public static TeamMenu getInstance(Scanner scanner, User user, Task task) {
        if (instance == null) {
            instance = new TeamMenu(scanner, user, task);
        }
        instance.scanner = scanner;
        instance.user = user;
        instance.task = task;
        return instance;
    }

    public void main() {
        System.out.println("Team Menu: ");
        System.out.println("0- Back");
        String input = scanner.nextLine();
        if (input.equals("0")) {
            MainMenu.getInstance(scanner, user, task).showMainMessage();
        } else if () {

        } else
            TeamMenu.getInstance(scanner, user, task).main();
    }

    public void showAllTeams(User user) {

    }
}
