package view;

import model.Task;
import model.User;

import java.util.Scanner;

public class TasksPage {

    // make class singleton
    private TasksPage(Scanner scanner, User user, Task task) {
        this.scanner = scanner;
        this.user = user;
        this.task = task;
    }

    private static TasksPage instance;
    private Scanner scanner;
    private User user;
    private Task task;

    public static TasksPage getInstance(Scanner scanner, User user, Task task) {
        if (instance == null) {
            instance = new TasksPage(scanner, user, task);
        }
        instance.scanner = scanner;
        instance.user = user;
        instance.task = task;
        return instance;
    }

    public void main() {
        System.out.println("<Task Menu>");
        TasksPage.getInstance(scanner,user,task).showTaskInfo(task);
        System.out.println("0- Back");
        String input = scanner.nextLine();
        if (input.equals("0")) {
            MainMenu.getInstance(scanner, user, task).showMainMessage();
        } else if () {

        } else
            TasksPage.getInstance(scanner, user, task).main();
    }

    public void showTaskInfo(Task task) {
        System.out.println("Task Id: " + task.getId());
        System.out.println("Task Title: " + task.getTitle());
        System.out.println("Task Description: " + task.getDescription());
        System.out.println("Task Priority: " + task.getPriority());
        System.out.println("Task Date and Time of Creation: " + task.getDateAndTimeOfCreation());
        System.out.println("Task Date and Time of Deadline: " + task.getDateAndTimeOfDeadline());
        System.out.println("Assigned Users: \n");
        task.getAssignedUsers();
        System.out.println();
    }
}
