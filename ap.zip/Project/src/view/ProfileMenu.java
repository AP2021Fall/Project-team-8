package view;

import model.Task;
import model.User;

import java.util.Scanner;

public class ProfileMenu {

    // make class singleton
    private ProfileMenu(Scanner scanner, User user, Task task) {
        this.scanner = scanner;
        this.user = user;
        this.task = task;
    }

    private static ProfileMenu instance;
    private Scanner scanner;
    private User user;
    private Task task;

    public static ProfileMenu getInstance(Scanner scanner, User user, Task task) {
        if (instance == null) {
            instance = new ProfileMenu(scanner, user, task);
        }
        instance.scanner = scanner;
        instance.user = user;
        instance.task = task;
        return instance;
    }

    public void main() {
        System.out.println("Profile Menu: ");
        System.out.println("0- Back");
        String input = scanner.nextLine();
        if (input.equals("0")) {
            MainMenu.getInstance(scanner, user, task).showMainMessage();
        } else if () {

        } else
            ProfileMenu.getInstance(scanner, user, task).main();
    }

    public void changePassword(User user, String oldPass, String newPass) {
        if (user.getPassword().equals(oldPass)) {
            if (!user.getPassword().equals(newPass)) {
                if (User.checkPasswordPattern(newPass)) {
                    System.out.println("Password changed successfully!");
                    user.setUserLogIn(false);
                    WelcomeMenu.getInstance(scanner).showWelcomeMessage();
                } else {
                    System.out.println("Please Choose A strong Password (Containing at least 8 characters including 1 digit\n" +
                            "and 1 Capital Letter)");
                    WelcomeMenu.getInstance(scanner).showWelcomeMessage();
                }
            } else {
                System.out.println("Please type a New Password!");
                WelcomeMenu.getInstance(scanner).showWelcomeMessage();
            }
        } else {
            System.out.println("wrong old password!");
            WelcomeMenu.getInstance(scanner).showWelcomeMessage();
        }
    }

    public void changeUsername(User user, String username) {
        if (username.length() < 4) {
            System.out.println("Your new username must include at least 4 characters!");
            WelcomeMenu.getInstance(scanner).showWelcomeMessage();
        } else {
            if (User.isUsernameUnique(username)) {
                if (User.checkUsernamePattern(username)) {
                    if (!user.getUsername().equals(username)) {
                        System.out.println("Your username changed successfully!");
                        user.setUsername(username);
                        WelcomeMenu.getInstance(scanner).showWelcomeMessage();
                    } else {
                        System.out.println("you already have this username!");
                    }
                } else {
                    System.out.println("New username contains Special Characters! Please remove them and try again");
                    WelcomeMenu.getInstance(scanner).showWelcomeMessage();
                }
            } else {
                System.out.println("username already taken!");
                WelcomeMenu.getInstance(scanner).showWelcomeMessage();
            }
        }
    }
}
