package view;

import model.Task;
import model.User;

import java.util.Scanner;

public class MainMenu {

    // make class singleton
    private MainMenu(Scanner scanner, User user, Task task) {
        this.scanner = scanner;
        this.user = user;
        this.task = task;
    }

    private static MainMenu instance;
    private Scanner scanner;
    private User user;
    private Task task;

    public static MainMenu getInstance(Scanner scanner, User user, Task task) {
        if (instance == null) {
            instance = new MainMenu(scanner, user, task);
        }
        instance.scanner = scanner;
        instance.user = user;
        instance.task = task;
        return instance;
    }


    public void showMainMessage() {
        System.out.println("Main Menu:");
        System.out.println("Your username: " + user.getUsername());

        System.out.println("1- Profile Menu");
        System.out.println("2- Team Menu");
        System.out.println("3- Tasks Page");
        System.out.println("4- Calender Menu");
        System.out.println("5- Notification Bar");
        System.out.println("0- Back");

        int input = scanner.nextInt();
        if (input == 1) {
            ProfileMenu.getInstance(scanner, user, task).main();
        } else if (input == 2) {
            TeamMenu.getInstance(scanner, user, task).main();
        } else if (input == 3) {
            TasksPage.getInstance(scanner,user,task).main();
        } else if (input == 4) {
            CalenderMenu.getInstance(scanner, user, task).main();
        }else if (input == 5) {
            NotificationBar.getInstance(scanner, user, task).main();
        }else if (input == 0) {

        } else {
            System.out.println("ERROR: Please enter a valid input!");
            MainMenu.getInstance(scanner, user, task).showMainMessage();
        }
    }
}