package view;

import model.Task;
import model.User;

import java.util.Scanner;

public class CalenderMenu {

    // make class singleton
    private CalenderMenu(Scanner scanner, User user, Task task) {
        this.scanner = scanner;
        this.user = user;
        this.task = task;
    }

    private static CalenderMenu instance;
    private Scanner scanner;
    private User user;
    private Task task;

    public static CalenderMenu getInstance(Scanner scanner, User user, Task task) {
        if (instance == null) {
            instance = new CalenderMenu(scanner, user, task);
        }
        instance.scanner = scanner;
        instance.user = user;
        instance.task = task;
        return instance;
    }

    public void main() {
        System.out.println("Calender Bar:");
        System.out.println("0- Back");
        String input = scanner.nextLine();
        if (input.equals("0")) {
            MainMenu.getInstance(scanner, user, task).showMainMessage();
        } else if () {

        } else
            CalenderMenu.getInstance(scanner, user, task).main();
    }
}
