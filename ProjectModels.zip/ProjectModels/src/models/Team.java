import java.util.ArrayList;
import java.util.HashMap;

public class Team {
    private static ArrayList<Team> teams = new ArrayList<>();
    private static ArrayList<Team> pendingTeams = new ArrayList<>();
    private static int IDCounter;
    private ArrayList<User> members = new ArrayList<>();
    private ArrayList<Task> tasks = new ArrayList<>();
    private ArrayList<Task> doneTasks = new ArrayList<>();
    private ArrayList<Task> failedTasks = new ArrayList<>();
    private ArrayList<Board> boards = new ArrayList<>();
    private HashMap<User,String> chatRoom = new HashMap<>();
    private HashMap<User,Integer> scoreboard = new HashMap<>();
    private String name;
    private final int number;
    private User leader;
    private Board selectedBoard;
    Team(String name,User leader){
        number = IDCounter;
    }

    public static boolean checkTeamNameFormat(String name){
        return false;
    }

    public static Team findTeamByName(String username){
        return null;
    }

    public static Team findTeamByNumber(int number){
        return null;
    }

    public static User checkMemberExist(String username){
        return null;
    }

    public void addUser(User user){

    }

    public void removeUser(User user){

    }

    public void changeLeader(User newLeader){

    }

    public void addBoard(Board board){

    }

    public void removeBoard(Board board){

    }

    public void selectBoard(Board board){

    }

    public void deselectBoard(Board board){

    }

    public static void setTeams(ArrayList<Team> teams) {
        Team.teams = teams;
    }

    public static void setPendingTeams(ArrayList<Team> pendingTeams) {
        Team.pendingTeams = pendingTeams;
    }

    public static void setIDCounter(int IDCounter) {
        Team.IDCounter = IDCounter;
    }

    public void setMembers(ArrayList<User> members) {
        this.members = members;
    }

    public void setTasks(ArrayList<Task> tasks) {
        this.tasks = tasks;
    }

    public void setDoneTasks(ArrayList<Task> doneTasks) {
        this.doneTasks = doneTasks;
    }

    public void setFailedTasks(ArrayList<Task> failedTasks) {
        this.failedTasks = failedTasks;
    }

    public void setBoards(ArrayList<Board> boards) {
        this.boards = boards;
    }

    public void setChatRoom(HashMap<User, String> chatRoom) {
        this.chatRoom = chatRoom;
    }

    public void setScoreboard(HashMap<User, Integer> scoreboard) {
        this.scoreboard = scoreboard;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLeader(User leader) {
        this.leader = leader;
    }

    public void setSelectedBoard(Board selectedBoard) {
        this.selectedBoard = selectedBoard;
    }

    public static ArrayList<Team> getTeams() {
        return teams;
    }

    public static ArrayList<Team> getPendingTeams() {
        return pendingTeams;
    }

    public static int getIDCounter() {
        return IDCounter;
    }

    public ArrayList<User> getMembers() {
        return members;
    }

    public ArrayList<Task> getTasks() {
        return tasks;
    }

    public ArrayList<Task> getDoneTasks() {
        return doneTasks;
    }

    public ArrayList<Task> getFailedTasks() {
        return failedTasks;
    }

    public ArrayList<Board> getBoards() {
        return boards;
    }

    public HashMap<User, String> getChatRoom() {
        return chatRoom;
    }

    public HashMap<User, Integer> getScoreboard() {
        return scoreboard;
    }

    public String getName() {
        return name;
    }

    public int getNumber() {
        return number;
    }

    public User getLeader() {
        return leader;
    }

    public Board getSelectedBoard() {
        return selectedBoard;
    }
}
