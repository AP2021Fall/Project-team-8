import java.util.ArrayList;
import java.util.Date;

public class User {
    private static ArrayList<User> users = new ArrayList<>();
    private static int IDCounter;
    private ArrayList<String> oldPasswords = new ArrayList<>();
    private ArrayList<Team> teams = new ArrayList<>();
    private ArrayList<Date> logins = new ArrayList<>();
    private ArrayList<Notification> notifications = new ArrayList<>();
    private ArrayList<Task> tasks =new ArrayList<>();
    private String username;
    private String password;
    private String email;
    private enum type {
        systemAdmin("systemAdmin"),
        teamLeader("teamLeader"),
        teamMember("teamMember");
        type(String systemAdmin) {
        }
    }
    private final int ID;
    private final Date createDate;
    private int allScores;
    User(String username, String password, String email, Date createDate){
        ID = IDCounter;
        IDCounter ++;
        this.createDate = createDate;
    }

    public static boolean checkUsernameCorrection(String username){
        return false;
    }

    public static boolean checkPasswordCorrection(String password){
        return false;
    }

    public static boolean checkEmailCorrection(String password){
        return false;
    }

    public static User findUserByUsername(String username){
        return null;
    }

    public static User findUserByID(int id){
        return null;
    }

    public boolean checkInOldPassword(String password){
        return false;
    }

    public void addLoginDate(Date date){

    }

    public void addNotification(Notification notification){

    }

    public void addUserToTeam(Team team){

    }

    public static ArrayList<User> getUsers() {
        return users;
    }

    public static int getIDCounter() {
        return IDCounter;
    }

    public ArrayList<String> getOldPasswords() {
        return oldPasswords;
    }

    public ArrayList<Team> getTeams() {
        return teams;
    }

    public ArrayList<Date> getLogins() {
        return logins;
    }

    public ArrayList<Notification> getNotifications() {
        return notifications;
    }

    public ArrayList<Task> getTasks() {
        return tasks;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public int getID() {
        return ID;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public int getAllScores() {
        return allScores;
    }

    public static void setUsers(ArrayList<User> users) {
        User.users = users;
    }

    public static void setIDCounter(int IDCounter) {
        User.IDCounter = IDCounter;
    }

    public void setOldPasswords(ArrayList<String> oldPasswords) {
        this.oldPasswords = oldPasswords;
    }

    public void setTeams(ArrayList<Team> teams) {
        this.teams = teams;
    }

    public void setLogins(ArrayList<Date> logins) {
        this.logins = logins;
    }

    public void setNotifications(ArrayList<Notification> notifications) {
        this.notifications = notifications;
    }

    public void setTasks(ArrayList<Task> tasks) {
        this.tasks = tasks;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAllScores(int allScores) {
        this.allScores = allScores;
    }


}
