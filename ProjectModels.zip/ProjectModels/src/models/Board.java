import java.util.ArrayList;
import java.util.HashMap;

public class Board {
    private static ArrayList<Board> boards = new ArrayList<>();
    private static int IDCounter;
    private HashMap<String,ArrayList<Task>> categories = new HashMap<>();
    private ArrayList<String> categoriesName = new ArrayList<>();
    private String name;
    private int ID;
    private Team team;

    Board(String name,Team team){

    }

    private void addCategory(String category){

    }

    private void addTask(Task task){

    }

    public static void setBoards(ArrayList<Board> boards) {
        Board.boards = boards;
    }

    public static void setIDCounter(int IDCounter) {
        Board.IDCounter = IDCounter;
    }

    public void setCategories(HashMap<String, ArrayList<Task>> categories) {
        this.categories = categories;
    }

    public void setCategoriesName(ArrayList<String> categoriesName) {
        this.categoriesName = categoriesName;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public static ArrayList<Board> getBoards() {
        return boards;
    }

    public static int getIDCounter() {
        return IDCounter;
    }

    public HashMap<String, ArrayList<Task>> getCategories() {
        return categories;
    }

    public ArrayList<String> getCategoriesName() {
        return categoriesName;
    }

    public String getName() {
        return name;
    }

    public int getID() {
        return ID;
    }

    public Team getTeam() {
        return team;
    }
}
