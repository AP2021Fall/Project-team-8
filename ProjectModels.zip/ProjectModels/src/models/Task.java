import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Task {
    private static ArrayList<Task> tasks = new ArrayList<>();
    private static int IDCounter;
    private ArrayList<User> assignedUsers = new ArrayList<>();
    private HashMap<User,String> Comments = new HashMap<>();
    private String title;
    private int ID;
    private String Description;
    private Date creationDate;
    private Date deadline;
    private Team team;
    private int completedPercentage;
    private Board board;
    private String category;
    private Boolean endCompletely;
    private enum priority {
        highest(" highest"),
        high("high"),
        low("low"),
        lowest("lowest");
        priority(String priority) {
        }
    }

    Task(String title,String category,Board board,Team team,Date deadline,Date creationDate){

    }

    public boolean checkDateCorrection(Date date){
        return false;
    }

    public void removeUserFromAssigned(User user){

    }

    public void addUserToAssigned(User user){

    }

    public void finishTask(){

    }

    public static void setTasks(ArrayList<Task> tasks) {
        Task.tasks = tasks;
    }

    public static void setIDCounter(int IDCounter) {
        Task.IDCounter = IDCounter;
    }

    public void setAssignedUsers(ArrayList<User> assignedUsers) {
        this.assignedUsers = assignedUsers;
    }

    public void setComments(HashMap<User, String> comments) {
        Comments = comments;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public void setCompletedPercentage(int completedPercentage) {
        this.completedPercentage = completedPercentage;
    }

    public void setBoard(Board board) {
        this.board = board;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setEndCompletely(Boolean endCompletely) {
        this.endCompletely = endCompletely;
    }

    public static ArrayList<Task> getTasks() {
        return tasks;
    }

    public static int getIDCounter() {
        return IDCounter;
    }

    public ArrayList<User> getAssignedUsers() {
        return assignedUsers;
    }

    public HashMap<User, String> getComments() {
        return Comments;
    }

    public String getTitle() {
        return title;
    }

    public int getID() {
        return ID;
    }

    public String getDescription() {
        return Description;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public Date getDeadline() {
        return deadline;
    }

    public Team getTeam() {
        return team;
    }

    public int getCompletedPercentage() {
        return completedPercentage;
    }

    public Board getBoard() {
        return board;
    }

    public String getCategory() {
        return category;
    }

    public Boolean getEndCompletely() {
        return endCompletely;
    }
}
