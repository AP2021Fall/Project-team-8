import java.util.ArrayList;

public class Notification {
    private static ArrayList<Notification> notifications = new ArrayList<>();
    private static int IDCounter;
    private String message;
    private int ID;

    Notification(String message){

    }

    private static void removeNotification(Notification notification){

    }

    public static ArrayList<Notification> getNotifications() {
        return notifications;
    }

    public static int getIDCounter() {
        return IDCounter;
    }

    public String getMessage() {
        return message;
    }

    public int getID() {
        return ID;
    }

    public static void setNotifications(ArrayList<Notification> notifications) {
        Notification.notifications = notifications;
    }

    public static void setIDCounter(int IDCounter) {
        Notification.IDCounter = IDCounter;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
}
